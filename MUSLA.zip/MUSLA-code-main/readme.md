Multiview Unsupervised Shapelet Learning for Multivariate Time Series Clustering

--------------------------------- download datasets ---------------------------------
All data sets are freely available on the website  http://www.timeseriesclassification.com/dataset.php

------------------------------------- run codes -------------------------------------
1. Open folder "run_code". 
2. Run "demo_USLA.m" for USLA  or Run "demo_MUSLA.m" for MUSLA 