# mts-clustering
Multivariate extensions to existing partitional time series clustering algorithms presented and implemented in;

http://snap.stanford.edu/data/ksc.html

http://www.cs.columbia.edu/~jopa/kshape.html

Python and Matlab implementations of the algorithms presented in the paper titled "Discovering Patterns of Online Popularity from Time Series" 

https://arxiv.org/pdf/1904.04994

https://www.public.asu.edu/~mozer/dipm-SC/supp_material.pdf
